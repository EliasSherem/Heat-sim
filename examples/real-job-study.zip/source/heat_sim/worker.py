"""Background job process: keeps Streamlit responsive during solver runs."""
from __future__ import annotations
import argparse
from datetime import datetime, timezone
import json
from pathlib import Path
import traceback

from .storage import atomic_json, snapshot_source


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("request", type=Path)
    args = parser.parse_args()
    folder = args.request.parent
    request = json.loads(args.request.read_text())
    status_file = folder / "status.json"
    def progress(fraction, message):
        atomic_json(status_file, {"state": "running", "progress": float(fraction), "message": message,
                                   "updated_utc": datetime.now(timezone.utc).isoformat()})
    try:
        snapshot_source(folder)
        progress(0, "Loading numerical model (first run compiles CPU kernels)")
        from .workflows import run_workflow
        from .solver import SimulationCancelled
        if request["kind"] in ("build", "transfer"):
            from .job_import import load_job
            from .build_solver import BuildConfig, run_build
            job_path = Path(request["job_path"])
            if not job_path.is_absolute():
                job_path = folder / job_path
            job = load_job(job_path, progress=lambda f,msg: progress(.02*f,msg))
            build_values = dict(request["build_config"])
            if build_values.get("geometry_file") and not Path(build_values["geometry_file"]).is_absolute():
                build_values["geometry_file"] = str((folder / build_values["geometry_file"]).resolve())
            config = BuildConfig(**build_values)
            if request["kind"] == "build":
                run_build(job, config, folder, progress=progress,
                    cancel=lambda: (folder / "CANCEL").exists())
            else:
                from .transfer import run_transfer
                run_transfer(job, config, request.get("options", {}), folder,
                    progress=progress, cancel=lambda: (folder / "CANCEL").exists())
        elif request["kind"] == "render":
            from dataclasses import replace
            from .solver import SimulationConfig
            from .render import render_simulation
            alloy = request.get("options", {}).get("render_alloy", "17-4PH")
            alpha = request.get("options", {}).get("absorptivity_316" if alloy == "316L" else "absorptivity_17", .35)
            config = replace(SimulationConfig(**request["config"]), alloy=alloy, absorptivity=alpha)
            manifest = render_simulation(config, folder, progress=progress,
                cancel=lambda: (folder / "CANCEL").exists())
            row = {"label": f"{alloy} instantaneous playback", "scenario": "nominal", "alloy": alloy,
                   "power_w": config.power_w, "speed_mm_s": config.speed_m_s*1000,
                   "cache_key": manifest["cache_key"], **manifest["metrics"]}
            atomic_json(folder / "report.json", {"kind": "render", "rows": [row], "extra": manifest,
                "fingerprint": manifest["model_fingerprint"]})
        elif request["kind"] == "verification":
            from .verification import run_verification
            from .storage import RESULTS
            verification = run_verification(include_sensitivity=True, progress=progress,
                cancel=lambda: (folder / "CANCEL").exists())
            atomic_json(RESULTS / "verification.json", verification)
            atomic_json(folder / "report.json", {"kind": "verification", "rows": [], "extra": verification})
            if not verification.get("numerical_checks_passed", False):
                raise ValueError("Numerical verification failed; inspect the saved report")
        else:
            run_workflow(request, folder, progress, lambda: (folder / "CANCEL").exists())
        atomic_json(status_file, {"state": "complete", "progress": 1., "message": "Results saved"})
    except BaseException as exc:
        cancelled = exc.__class__.__name__ == "SimulationCancelled"
        atomic_json(status_file, {"state": "cancelled" if cancelled else "failed", "progress": 0.,
                                   "message": str(exc), "exception": type(exc).__name__})
        if not cancelled:
            (folder / "traceback.txt").write_text(traceback.format_exc())
            raise


if __name__ == "__main__":
    main()
